 
 CREATE TABLE posts (
    id int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    date VARCHAR(20),
    publication VARCHAR(150), 
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL  
);
  
 CREATE TABLE products (
    id int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    family VARCHAR(20),
    carbohydrates VARCHAR(150),
    protein FLOAT(2,0),
    calories FLOAT(2,0),
	sugar  FLOAT(2,0),
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL  
);

 