const Pool = require('mysql').Pool;
const pool = new Pool({
  user: 'root',
  host: 'localhost',
  database: 'api',
  password: '',
  port: 3306,
});

/*-----------------CREACION DE API PARA CONSULTA DE LOS PRODUCTOS-----------------*/
/*CONSULTAR PRODUCTO*/
const getProduct = (request, response) => {
  pool.query('SELECT * FROM users ORDER BY id ASC', (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};

/*CONSULTAR PRODUCTO POR ID*/
const getProductById = (request, response) => {
  const id = parseInt(request.params.id);
  pool.query('SELECT * FROM products WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};

/*CONSULTAR CREAR PRODUCTO*/
const createProduct = (request, response) => {
  const { name, family ,carbohydrates ,protein, calories, sugar } = request.body;

  pool.query(
    'INSERT INTO products (name, family ,carbohydrates ,protein, calories, sugar ) VALUES ($1, $2, $3 , $4 , $5 , $6) RETURNING *',
    [name, family ,carbohydrates ,protein, calories, sugar],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(201).send(`Producto Registrado Correctamente: ${results.rows[0].id}`);
    }
  );
};

/*CONSULTAR ACTUALIZAR PRODUCTO*/
const updateProduct = (request, response) => {
  const id = parseInt(request.params.id);
  const { name, family ,carbohydrates ,protein, calories, sugar } = request.body;

  pool.query(
    'UPDATE products SET name = $1, family = $2 ,carbohydrates = $3, protein = $4 ,calories = $5, sugar = $6 WHERE id = $7',
    [name, family ,carbohydrates ,protein, calories, sugar, id],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).send(`Producto Actualizado Correctamente: ${id}`);
    }
  );
};

/*CONSULTAR ELIMINAR PRODUCTO*/
const deleteProduct = (request, response) => {
  const id = parseInt(request.params.id);

  pool.query('DELETE FROM products WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).send(`Producto Eliminado Correctamente: ${id}`);
  });
};


/*-----------------CREACION DE API PARA CONSULTA DE LOS POSTS-----------------*/
/*CONSULTAR POSTS*/
const getPosts = (request, response) => {
  pool.query('SELECT * FROM posts ORDER BY id ASC', (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};
/*CONSULTAR POSTS POR ID*/
const getPostsById = (request, response) => {
  const id = parseInt(request.params.id);
  pool.query('SELECT * FROM posts WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};


	
/*CONSULTAR CREAR POSTS*/
const createPosts = (request, response) => {
  const { name, date ,publication } = request.body;

  pool.query(
    'INSERT INTO posts (name, date ,publication) VALUES ($1, $2, $3) RETURNING *',
    [name, date ,publication],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(201).send(`Posts Registrado Correctamente: ${results.rows[0].id}`);
    }
  );
};

/*CONSULTAR ACTUALIZAR POSTS*/
const updatePosts = (request, response) => {
  const id = parseInt(request.params.id);
  const { name, date ,publication } = request.body;

  pool.query(
    'UPDATE posts SET name = $1, date = $2 ,publication = $3 WHERE id = $4',
    [name, date ,publication],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).send(`Posts Actualizado Correctamente: ${id}`);
    }
  );
};

/*CONSULTAR ELIMINAR POSTS*/
const deletePosts = (request, response) => {
  const id = parseInt(request.params.id);

  pool.query('DELETE FROM posts WHERE id = $1', [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).send(`Posts Eliminado Correctamente: ${id}`);
  });
};

module.exports = {
  getProduct,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getPosts,
  getPostsById,
  createPosts,
  updatePosts,
  deletePosts,
};

