const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

const db = require('./api-rest');

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

app.get('/', (request, response) => {
  response.json({ info: 'Server Fresh-Frutis, MYSQL, Express, API' });
});

/*API DE PRODUCTOS METODO GET POST PUT DELETE*/
app.get('/products', db.getProduct);
app.get('/products/:id', db.getProductById);
app.post('/products', db.createProduct);
app.put('/products/:id', db.updateProduct);
app.delete('/products/:id', db.deleteProduct);

/*API DE PRODUCTOS METODO GET POST PUT DELETE*/
app.get('/posts', db.getPosts);
app.get('/posts/:id', db.getPostsById);
app.post('/posts', db.createPosts);
app.put('/posts/:id', db.updatePosts);
app.delete('/posts/:id', db.deletePosts);

app.listen(port, () => {
  console.log(`Server Corriendo en el Puerto ${port}.`);
});
